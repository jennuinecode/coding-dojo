$(document).ready(function(){
    $("button").click(function(){
     var userName = $("input").val();
     $("table").append("<p>hello</p>")
        console.log(userName);
        return false
    });




}) //end of jQuery
