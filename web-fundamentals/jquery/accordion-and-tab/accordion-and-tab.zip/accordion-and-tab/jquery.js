$(document).ready(function(){
    $( "#dialog" ).dialog();
    $("#accordion").accordion();
    $("#tabs").tabs()
    $("li").click(function(){
        $(this).css("background-color" , "#666699");

    })
})
